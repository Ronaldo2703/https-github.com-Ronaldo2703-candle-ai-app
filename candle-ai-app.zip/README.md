# Candle AI

Una aplicación web para analizar gráficos de velas con inteligencia artificial.