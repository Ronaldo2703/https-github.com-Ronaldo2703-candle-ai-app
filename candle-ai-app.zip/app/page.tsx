export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Candle AI</h1>
      <p>Bienvenido a tu asistente inteligente de análisis de velas japonesas.</p>
    </main>
  );
}