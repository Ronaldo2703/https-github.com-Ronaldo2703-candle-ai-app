# Candle AI App
Una aplicación para análisis de velas.