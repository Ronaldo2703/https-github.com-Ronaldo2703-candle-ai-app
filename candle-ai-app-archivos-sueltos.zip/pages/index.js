export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Candle AI</h1>
      <p>Bienvenido a la aplicación de análisis de velas con inteligencia artificial.</p>
    </div>
  );
}