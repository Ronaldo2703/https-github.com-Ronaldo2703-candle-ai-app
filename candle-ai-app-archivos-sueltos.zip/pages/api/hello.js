export default function handler(req, res) {
  res.status(200).json({ name: 'API activa de Candle AI' })
}