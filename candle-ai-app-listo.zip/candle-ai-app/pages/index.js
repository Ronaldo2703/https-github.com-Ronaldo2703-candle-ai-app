export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Candle AI</h1>
      <p>Bienvenido a la aplicación de análisis de velas con inteligencia artificial.</p>
      <p>Muy pronto podrás subir una imagen de gráfico de velas y recibir predicciones automáticas.</p>
    </main>
  );
}