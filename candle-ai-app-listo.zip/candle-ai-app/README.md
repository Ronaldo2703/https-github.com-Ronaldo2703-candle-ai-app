# Candle AI

App para análisis de velas con inteligencia artificial.